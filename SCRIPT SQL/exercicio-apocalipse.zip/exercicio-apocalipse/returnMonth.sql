DELIMITER $$
CREATE FUNCTION `returnMonth`(
    strDate VARCHAR(20)
) RETURNS CHAR(2) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    DETERMINISTIC
BEGIN
    DECLARE v_Month VARCHAR(5);
    DECLARE v_monthNumber INT;

    SET v_Month = substring(strDate, 4, 3);

    SELECT monthNumber
    INTO v_monthNumber
    FROM (VALUES
        ROW (01,'JAN'),
        ROW (02,'FEB'),
        ROW (03,'MAR'),
        ROW (04,'APR'),
        ROW (05,'MAY'),
        ROW (06,'JUN'),
        ROW (07,'JUL'),
        ROW (08,'AUG'),
        ROW (09,'SEP'),
        ROW (10,'OCT'),
        ROW (11,'NOV'),
        ROW (12,'DEC')
        ) Months (monthNumber, monthName)
    WHERE monthName = v_Month;

    RETURN LPAD(v_monthNumber,2,'0');
END $$
DELIMITER ;