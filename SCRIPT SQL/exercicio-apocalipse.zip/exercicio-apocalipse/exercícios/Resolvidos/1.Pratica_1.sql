/*
1. Fazer o script de criação das tabelas
2. Popular as tabelas (disponível do github)
3. Inserir um cliente com o seu próprio nome
*/
INSERT INTO CUSTOMERS(NAME, ADDRESS, WEBSITE, CREDIT_LIMIT)
VALUES('Daniel Sângelo Enterprise', '900 Ameixas Ave, Belo Horizonte, MG', 'www.dspenterprise.com.br', 100000)
/
-- 4. Inserir um funcionário com o nome de um amigo
INSERT INTO EMPLOYEES(FIRST_NAME, LAST_NAME, EMAIL, PHONE, HIRE_DATE, MANAGER_ID, JOB_TITLE)
VALUES('JULIO', 'JR', 'julio@company.com', to_date('20/07/2000', 'DD/MM/YYYY'), NULL, 'MANAGER')
/

--5. Fazer uma query para retornar apenas os clientes que têm 3 pedidos ou mais
-- RESULTADO ESPERADO: 17 registros atualizados
*/
select count(1), c.customer_id 
  from customers c
  join orders o
    on c.customer_id = o.customer_id
 group by c.customer_id
 having count(1) >=3

--6. Atualizar o campo CREDIT_LIMIT em 20% apenas para os clientes com mais de 3 pedidos. 
-- RESULTADO ESPERADO: 17 registros atualizados
UPDATE CUSTOMERS
   SET CREDIT_LIMIT = CREDIT_LIMIT * 0.2
 WHERE CUSTOMER_ID IN (
						SELECT C.CUSTOMER_ID 
						  FROM CUSTOMERS C
						  JOIN ORDERS O
							ON C.CUSTOMER_ID = O.CUSTOMER_ID
						 GROUP BY C.CUSTOMER_ID
						 HAVING COUNT(1) > 3
						 )



/*
7. Alguns clientes têm em seus nomes a seguinte sequência de caracteres: ' * '. Atualizar o nome deles
substituindo o * por &
*/
-- example with EXISTS
UPDATE CUSTOMERS
   SET NAME = REPLACE(NAME, ' * ', ' & ')
 WHERE EXISTS (
                SELECT 1
                  FROM CUSTOMERS C
                 WHERE C.NAME LIKE '% * %'
                   AND CUSTOMERS.CUSTOMER_ID = C.CUSTOMER_ID
              )
/*
8. A tabela ORDERS possui um campo chamado STATUS. Altera-lo para que seja adicionada uma constraint do tipo check
que permita apenas os valores: 'Shipped', 'Pending', 'Canceled'. obs.: os registros foram incluídos no banco com camel-case. Após a criação
da constraint os novos registros deverão ser incluídos com as letras maiúsculas (ex.: 'SHIPPED', 'PENDING', 'CANCELED').
DICA: vai acontecer um erro ao criar a constraint. Antes de criar a constraint, que tal considerar a função UPPER.
*/
ALTER TABLE ORDERS MODIFY STATUS VARCHAR2(20) DEFAULT 'PENDING'
/
UPDATE ORDERS
   SET STATUS = UPPER(STATUS)
/
ALTER TABLE ORDERS ADD CONSTRAINT CKC_ORDERSTATUS CHECK (STATUS IN ('SHIPPED', 'PENDING', 'CANCELED'))
/
-- 9. Criar uma consulta que retorne apenas os produtos com a palavra 'asus' em seu nome
SELECT PRODUCT_ID, PRODUCT_NAME
  FROM PRODUCTS
 WHERE UPPER(PRODUCT_NAME) LIKE '%ASUS%'
/

--10. Criar uma consulta que mostre a arrecadação total por pedido e ordene os resultados de forma decrescente
SELECT ORDER_ID, SUM(QUANTITY * UNIT_PRICE) AS TOTAL
  FROM ORDER_ITEMS
 GROUP BY ORDER_ID
 ORDER BY TOTAL DESC
/
--11. Calcule a média arrecadada em um período.
SELECT ROUND(AVG(QUANTITY * UNIT_PRICE),2) AS MEDIA
  FROM ORDERS O 
  JOIN ORDER_ITEMS OI
    ON O.ORDER_ID = OI.ORDER_ID
 WHERE O.ORDER_DATE BETWEEN :P_DATAINICIAL AND :P_DATAFINAL
/
--12. Com apenas um comando, criar uma tabela com os produtos dos pedidos que tiveram uma arrecadação acima da média do período
CREATE TABLE BIGGERTHANAVG AS SELECT PRODUCT_ID, PRODUCT_NAME, STANDARD_COST
                                FROM PRODUCTS 
                               WHERE STANDARD_COST > (SELECT ROUND(AVG(STANDARD_COST),2)
                                                        FROM PRODUCTS)
/
SELECT * FROM BIGGERTHANAVG
/

/*
13. Criar uma consulta que retorne todos os funcionários. Porém, os funcionários que tiverem o campo 'MANAGE_ID' igual a NULL deve exibir
um hífen em vez de NULL.
*/
SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME, 
       EMAIL, PHONE, HIRE_DATE, NVL(TO_CHAR(MANAGER_ID), '-') MANAGER_ID, JOB_TITLE
  FROM EMPLOYEES
/

--14. Aumente 5% o preço (LIST_PRICE) do produto mais pedido
UPDATE PRODUCTS
   SET LIST_PRICE = LIST_PRICE + (LIST_PRICE * 5/100)
 WHERE EXISTS (
                SELECT P.PRODUCT_ID
                  FROM PRODUCTS P
                  JOIN ORDER_ITEMS O
                    ON P.PRODUCT_ID = O.PRODUCT_ID
                 WHERE PRODUCTS.PRODUCT_ID = P.PRODUCT_ID
                 GROUP BY P.PRODUCT_ID
                 HAVING COUNT(1) = (SELECT MAX(COUNT(1)) QTDE
                                      FROM PRODUCTS P
                                      JOIN ORDER_ITEMS O
                                        ON P.PRODUCT_ID = O.PRODUCT_ID
                                     GROUP BY P.PRODUCT_ID
                                     )
)