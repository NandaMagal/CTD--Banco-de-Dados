DELIMITER $$
CREATE FUNCTION `to_date`(
    strDate VARCHAR(20),
    strInutil VARCHAR(20)
) RETURNS DATE
    DETERMINISTIC
begin
-- to_date('07-JUN-16')
    declare v_monthNumber CHAR(2);
    declare v_novaData VARCHAR(10);
    declare v_month CHAR(4);
    declare v_year CHAR(4);
    declare v_day CHAR(2);

    SET v_monthNumber = returnMonth(strDate); -- 06
    SET v_novaData = CONCAT(SUBSTRING(strDate,1,3), v_monthNumber, SUBSTRING(strDate,7,3)); -- dia-mes-ano
    SET v_day = SUBSTRING(v_novaData,1,2);
    SET v_month = SUBSTRING(v_novaData,4,2);
    SET v_year = SUBSTRING(v_novaData,7,2);
    SET v_novaData = CONCAT(v_year,'-',v_month,'-',v_day); -- ano-mes-dia

    RETURN v_novaData;
END $$
DELIMITER ;